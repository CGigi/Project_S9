<!DOCTYPE html>
<html>
	<body>

		<h1>Page to retreive Code</h1>
		<?php
			echo '<p> Code: '.$_GET['code'].'</p>';
		?>

	</body>
</html>