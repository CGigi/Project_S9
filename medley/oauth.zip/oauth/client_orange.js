var oauth2 = require('./client_oauth2');

oauth2.authenticate('./oauth_orange_cloud.json');