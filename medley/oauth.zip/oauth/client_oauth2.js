module.exports = {
  authenticate: function (jsonOptionFile) {
    getRequest(jsonOptionFile);
  }
}

var getGetOptions = function (jsonOptionFile, callback){
	var fs = require("fs");
	var contents = fs.readFileSync(jsonOptionFile);
	var jsonContent = JSON.parse(contents);
	var scopes = "";
	var i;
	for(i = 0; i < jsonContent.scopes.length -1 ; i++){
		scopes += jsonContent.scopes[i]+" ";
	}
	scopes += jsonContent.scopes[i];
	var options = {
		//host : jsonContent.authorizationUri.split("//")[1].split("/")[0],
		url : jsonContent.authorizationUri//+"?scope="+encodeURIComponent(scopes)
			+"?response_type=code"
			+"&client_id="+encodeURIComponent(jsonContent.clientId)
			+"&state=state"
			+"&redirect_uri="+encodeURIComponent(jsonContent.redirectUri),
		port : 443,
		methode : 'GET',
		followAllRedirects: true,
		headers: {
		    accept: '*/*'
		}
	};
	callback(options);
}

var getPostOptions = function(jsonOptionFile, callback){
	var fs = require("fs");
	var contents = fs.readFileSync(jsonOptionFile);
	var jsonContent = JSON.parse(contents);
}

var getRequest = function (jsonOptionFile) {
	var request = require('request');
	var open = require('open');

	var options;
	getGetOptions(jsonOptionFile, function(data){
        options = data;
    }); 
 
	console.info('Options prepared:');
	console.info(options);
	console.info('Do the GET call');

	var r = request.get(options, function (err, res, body) {
	 	if (err) {
	    	console.dir(err)
	    	return
	  	}
	  	if(res.statusCode == 200){
	  		open(r.uri.href);
	  		console.log('status',res.statusCode);
	  		getCode(function(code,server){
	  			console.log("code:", code);
	  			//TO DO: POST request to get token
	  		});
	  	}
	  	res.on('data', function(d) {
		    process.stdout.write(d);
		});
	});
}

var getCode = function (callback) {
	var express = require('express');
	var app = express();
	app.get('/oauth/orange/test.php', function (req, res) {
  		res.send('Hello World!');
  		callback(req.query.code, server);
	});
	var server = app.listen(3000, function () {
  		console.log('Example app listening on port 3000!');
	});
	
}

	/*var r = request.get(options, function (err, res, body) {
	 	if (err) {
	    	console.dir(err)
	    	return
	  	}
	  	var statusCode = res.statusCode
	  	console.log("status code: " , res.statusCode)
	  	open(r.uri.href);
	  	res.on('data', function(d) {
		    process.stdout.write(d);
		});
	});*/

	// do the GET request
	/*request(options, function(err,response,body) {
		if (err) {
			console.dir(err)
		    return
		}
	    console.log("statusCode: ", response.statusCode);
	    // uncomment it for header details
		//console.log("headers: ", response.headers);
	 	//console.log("response uri: ", request.uri);
	 	response.on('data', function(d) {
		    process.stdout.write(d);
		});

	 
	});

	request.end();

	request.on('error', function(e) {
		console.error("error",e);
	});*/
