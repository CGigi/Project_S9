/*
Ce module utilise le 'code' reçu par GetCloudCode et récupère un 'token'
*/
module.exports = (medley) => {

  const component = new medley.Component('Orange/GetFreeSpace');
  component.setHandlers({

    preInvoke: (context, bundle) => {
      return bundle;
    },

    invoke: (context, options, bundle) => {
      return medley.client.request({
        url: 'https://api.orange.com/cloud/v1/freespace',
        method: 'GET',
        json: true,
        qs: {
          format: 'json'
        },
        headers: {
          'Authorization': ''+context.access_token+' '+context.token_type+''
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        }
      });
    },

    postInvoke: (context, data) => {
      return data;
    }

  });

  return component;
};
