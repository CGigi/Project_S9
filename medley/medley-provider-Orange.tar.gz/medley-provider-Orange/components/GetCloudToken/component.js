/*
Ce module utilise le 'code' reçu par GetCloudCode et récupère un 'token'
*/
module.exports = (medley) => {

  const component = new medley.Component('Orange/GetCloudToken');
  component.setHandlers({

    preInvoke: (context, bundle) => {
      // avant d'interroger l'api il faut récupérer le 'code'
      GetCloudCode.invoke();
      return bundle;
    },

    invoke: (context, options, bundle) => {
      return medley.client.request({
        url: 'https://api.orange.com/oauth/v2/token',
        method: 'POST',
        json: true,
        qs: {
          format: 'json'
        },
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Basic '+btoa("client_id+":"+client_secret")
        }
        // Comment ajouter un body à une requête POST ?
        body:{
          'redirect_uri': ''+medley.client+'',
          'code': ''+context.code+''
          'grant_type': 'authorization_code'
        }
      });
    },

    postInvoke: (context, data) => {
      // on veut passer le token et token type pour les autres module, comment faire ?
      context.access_token=data.access_token;
      context.token_type=data.token_type;
      return data;
    }

  });

  return component;
};
