/*
ce module fait une requete http pour authentifier le user en demandant au user medley de s'authentifier sur le cloud d'orange
on recoit une requete GET avec un 'code' et un 'state'
le code sera utilisé dans GetCloudToken
*/
module.exports = (medley) => {

  const component = new medley.Component('Orange/GetCloudCode');
  component.setHandlers({

    preInvoke: (context, bundle) => {
      // Apply custom changes here
      return bundle;
    },

    invoke: (context, options, bundle) => {
      //Requete vers l'api orange pour s'authentifier
      return medley.client.request({
        url: 'https://api.orange.com/oauth/v2/authorize?scope=openid%20cloud&response_type=code&client_id='+medley.client_id+'&state=state&redirect_uri='+medley.client,
        method: 'GET',
        json: true,
        qs: {
          format: 'json'
        },
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });
    },

    postInvoke: (context, data) => {
      // on veut passer le code au module GetCloudToken (on sait pas comment faire)
      context.code = data.code;
      return data;
    }

  });

  return component;
};
