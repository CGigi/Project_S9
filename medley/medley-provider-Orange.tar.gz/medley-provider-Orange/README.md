# Ipify service provider

This module is a Medley wrapper for the Ipify service provider.
